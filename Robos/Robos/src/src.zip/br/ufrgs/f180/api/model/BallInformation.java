package br.ufrgs.f180.api.model;

/**
 *   This class contains the published information from the ball.
 *    
 * @author Gabriel
 *
 */
public class BallInformation extends ElementInformation {

}
