package br.ufrgs.f180.elements;

import org.eclipse.swt.graphics.GC;

public interface VisualElement {
	void draw(GC gc);
	int realx(double x);
	int realy(double y);
	int scalex(double x);
	int scaley(double y);
}
