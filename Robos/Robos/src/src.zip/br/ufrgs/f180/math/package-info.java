package br.ufrgs.f180.math;

/**
 *   This folder contains libraries used across programs.
 *  
 *   The main purpose is to provide a common library that can be used by client players to connect to tewnta and 
 *  easily interoperate with the simulator.  
 */
